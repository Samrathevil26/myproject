package runner;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.AfterClass;
import org.junit.runner.RunWith;

import com.aventstack.extentreports.ExtentReports;

import utils.ExtentReportManager;

@RunWith(Cucumber.class)
@CucumberOptions(
    features = "src/test/resources/features",
    glue = "stepdefinitions",
    plugin = {"pretty", "json:target/cucumber.json"}
)
public class reportRunner {

    @AfterClass
    public static void generateExtentReport() {
        ExtentReports.getInstance().flush();
    }
}
