package steps;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AndOr {

    @Given("a user has an account")
    public void userHasAccount() {
        System.out.println("User has an account");
    }

    @Given("the user is logged in")
    public void userIsLoggedIn() {
        System.out.println("User is logged in");
    }

    @When("the user performs action A and action B")
    public void userPerformsActionAAndB() {
        System.out.println("User performs action A and action B");
    }

    @Then("the result should be successful")
    public void resultShouldBeSuccessful() {
        System.out.println("Result is successful");
    }

    @When("the user performs either action X or action Y")
    public void userPerformsEitherActionXOrY() {
        System.out.println("User performs either action X or action Y");
    }
}
