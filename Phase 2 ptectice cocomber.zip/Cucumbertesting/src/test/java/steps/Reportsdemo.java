package steps;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Reportsdemo {

    @Given("the user is on the login page")
    public void userIsOnLoginPage() {
        System.out.println("User is on the login page");
    }

    @When("the user enters valid credentials")
    public void userEntersValidCredentials() {
        System.out.println("User enters valid credentials");
    }

    @Then("the user should be logged in successfully")
    public void userLoggedInSuccessfully() {
        System.out.println("User is logged in successfully");
    }
}
