// StepDefinitions.java

package steps;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class SampleTestSteps {

    @Given("I have a cucumber step")
    public void givenStep() {
        System.out.println("Cucumber Given step");
    }

    @When("I run the cucumber step")
    public void whenStep() {
        System.out.println("Cucumber When step");
    }
}
