package steps;

import io.cucumber.java.en.*;

public class TagScanario {

    @Given("the user enters number {int}")
    public void userEntersNumber(int number) {
        System.out.println("User enters number " + number);
    }

    @When("the user adds the numbers")
    public void userAddsNumbers() {
        System.out.println("User adds the numbers");
    }

    @When("the user subtracts the numbers")
    public void userSubtractsNumbers() {
        System.out.println("User subtracts the numbers");
    }

    @When("the user multiplies the numbers")
    public void userMultipliesNumbers() {
        System.out.println("User multiplies the numbers");
    }

    @Then("the result should be {int}")
    public void resultShouldBe(int expectedResult) {
        System.out.println("Expected Result: " + expectedResult);
    }
}
