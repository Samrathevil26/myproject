package steps;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class TestLoginFeature {

	@Given("I open the chrome browser")
	public void openBrowser() {
		System.out.println("This method will open browser");
	}

	@When("I enter the reddif mypage URl")
	public void openMypageURl() {
		System.out.println("This method will opent the URL");
	}

	@Then("I capture the title on the page")
	public void captureTitle() {
		System.out.println("This method will capture the title");
	}

	@Then("I enter the username as admin and password as admin@123")
	public void enterUsernameAndPassward() {
		System.out.println("this method will enter the username and password");
	}

	@When("I click on login button")
	public void clickOnLogin() {
		System.out.println("this method will chick on login");
	}

	@Then("I should to see an error massage")
	public void viewErrorMassage() {
		System.out.println("This mathod will show error massage");
	}

	@And("I click on the click here")
	public void clickonHere() {
		System.out.println("this mathod will click on the link");
	}

	@And("I close the browser")
	public void closeBrowser() {
		System.out.println("this method will close the browser");
	}

}
