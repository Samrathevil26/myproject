package steps;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class TaggedHooks {

    @Given("a user is on the Google homepage")
    public void userIsOnGoogleHomepage() {
        System.out.println("User is on the Google homepage");
    }

    @When("the user searches for {string}")
    public void userSearchesFor(String term) {
        System.out.println("User searches for: " + term);
    }

    @When("the user performs an image search for {string}")
    public void userPerformsImageSearch(String term) {
        System.out.println("User performs an image search for: " + term);
    }

    @Then("the search results page is displayed")
    public void searchResultsPageIsDisplayed() {
        System.out.println("Search results page is displayed");
    }

    @Then("the image search results page is displayed")
    public void imageSearchResultsPageIsDisplayed() {
        System.out.println("Image search results page is displayed");
    }
}
