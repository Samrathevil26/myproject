package hooks;

import io.cucumber.java.Before;
import io.cucumber.java.After;

public class GoogleHooks {

    @Before("@search")
    public void beforeSearchScenario() {
        System.out.println("Before the @search scenario: Setting up resources");
        // Perform setup tasks specific to @search scenario
    }

    @Before("@imageSearch")
    public void beforeImageSearchScenario() {
        System.out.println("Before the @imageSearch scenario: Setting up resources");
        // Perform setup tasks specific to @imageSearch scenario
    }

    @After("@search")
    public void afterSearchScenario() {
        System.out.println("After the @search scenario: Cleaning up resources");
        // Perform cleanup tasks specific to @search scenario
    }

    @After("@imageSearch")
    public void afterImageSearchScenario() {
        System.out.println("After the @imageSearch scenario: Cleaning up resources");
        // Perform cleanup tasks specific to @imageSearch scenario
    }
}
