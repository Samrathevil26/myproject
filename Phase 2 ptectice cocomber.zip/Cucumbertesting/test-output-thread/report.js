$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"84df9d96-04dc-4cde-9269-a584eb8b13ea","feature":"Create account on wiki page","scenario":"User creates account on wiki page using input from cucumber data table","start":1701324226597,"group":1,"content":"","tags":"","end":1701324227050,"className":"failed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});