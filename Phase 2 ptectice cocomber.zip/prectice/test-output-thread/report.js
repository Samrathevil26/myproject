$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"41ac5843-c89f-4c09-b8b3-1e020f035b19","feature":"Create account on wiki page","scenario":"User creates account on wiki page using input from cucumber data table","start":1701329066328,"group":1,"content":"","tags":"","end":1701329079191,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});