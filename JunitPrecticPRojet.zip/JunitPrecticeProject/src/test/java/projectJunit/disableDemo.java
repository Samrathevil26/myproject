package projectJunit;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

public class disableDemo {
	@Test
	public void method1() {
		System.out.println("Exicution method 1");
		
	}
	@Test
	public void method2() {
		System.out.println("Exicution method 2");
		
	}
	@Test
	@Disabled
	public void method3() {
		System.out.println("Exicution method 3");
		
	}
	@Test
	public void method4() {
		System.out.println("Exicution method 4");
		
	}

}
