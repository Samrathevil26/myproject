package projectJunit;
import java.util.stream.Stream;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;


public class ParameterizedDemoMethodSource {
	
	@ParameterizedTest
	@MethodSource("stringParameters")
	public void getDataMehtod(String input) {
		System.out.println("the value of the method is: "+ input);
	}
	public static Stream<String> stringParameters(){
		return Stream.of("Monday","Tuseday","Wednesday");
		
	}

}
