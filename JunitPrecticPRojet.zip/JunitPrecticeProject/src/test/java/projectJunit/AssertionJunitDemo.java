package projectJunit;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class AssertionJunitDemo {
	
	@Test
	public void testAssertion() {
		String Expected = new String("abc");
		String Actual =new String("abc");
		
		String str1=  "Junit";
		String str2= null;
		
		
		Assertions.assertEquals(Expected,Actual);
		Assertions.assertNotNull(str1);
	}

}
