package projectJunit;

import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;

public class RepeatTesting {
	@RepeatedTest(5)
	@DisplayName("Repeat test method")
	public void RepeatMassage() {
		System.out.println("We are learning Junit");
	}
	
	
	
	@Test
	public void AssumptionTest() {
		boolean isDbServerUp = true;
		Assumptions.assumeTrue(isDbServerUp, "Db server is not up or running");
		System.out.println("Create the table and insert the data");
	}

}
