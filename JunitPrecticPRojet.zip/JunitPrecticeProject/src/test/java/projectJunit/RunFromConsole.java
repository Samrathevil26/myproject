package projectJunit;

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.platform.suite.api.ExcludeTags;
import org.junit.platform.suite.api.IncludeTags;

@IncludeTags({ "development" })
@ExcludeTags({ "Production" })
public class RunFromConsole {
	@Test
	@Tag("development")
	public void devTest() {
		System.out.println("Test Case Development");
	}

	@Test
	@Tag("Development")
	public void devTest1() {
		System.out.println("Test case development1");
	}

	@Test
	@Tag("Quality Assurence")
	public void qaTest() {
		System.out.println("Test case QA");
	}

	@Test
	@Tag("Quality Assurence")
	public void qaTest1() {
		System.out.println("Test case QA 1");
	}

	@Test
	@Tag("Production")
	public void proTest() {
		System.out.println("Test case production");
	}

	@Test
	@Tag("Production")
	public void proTest1() {
		System.out.println("Test case production1");
	}

}
