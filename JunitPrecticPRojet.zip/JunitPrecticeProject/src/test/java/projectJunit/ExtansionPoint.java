package projectJunit;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledOnJre;
import org.junit.jupiter.api.condition.EnabledOnOs;
import org.junit.jupiter.api.condition.JRE;
import org.junit.jupiter.api.condition.OS;

public class ExtansionPoint {
	@Test
	@EnabledOnOs(OS.MAC)
	public void conditions() {
		System.out.println("Execute the test cases for mac");
	}
	@Test
	@EnabledOnOs(OS.WINDOWS)
	public void conditions1() {
		System.out.println("Execute the test cases for Windows");
	}
	@Test
	@EnabledOnJre(JRE.JAVA_17)
	public void conditionJRE() {
		System.out.println("Exeute the test cases for jre 17");
	}
	@Test
	@EnabledOnJre(JRE.JAVA_14)
	public void conditionJRE1() {
		System.out.println("Exeute the test cases for jre 14");
	}
}
