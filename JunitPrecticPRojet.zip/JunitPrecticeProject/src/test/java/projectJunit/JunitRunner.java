package projectJunit;

import org.junit.platform.runner.JUnitPlatform;
import org.junit.platform.suite.api.ExcludeTags;
import org.junit.platform.suite.api.SelectClasses;
import org.junit.runner.RunWith;

@SuppressWarnings("deprecation")
@RunWith(JUnitPlatform.class)
@SelectClasses({ projectJunit.RunFromConsole.class })
//@IncludeTags({"Prod"})
@ExcludeTags("Production")

public class JunitRunner {

}
