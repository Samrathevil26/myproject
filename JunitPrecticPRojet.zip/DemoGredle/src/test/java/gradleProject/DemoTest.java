package gradleProject;

import org.junit.jupiter.api.Test;

public class DemoTest {
	@Test
	public void GradleDemo() {
		System.out.println("Gredle demo test...");
	}

}
