package PageObjectModal;
//FacebookLoginTest.java
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class FacebookLoginTest {
 private WebDriver driver;
 private FacebookLoginPage facebookLoginPage;

 @BeforeMethod
 public void setUp() {
     // Set the path to the ChromeDriver executable
     // Initialize ChromeDriver
     driver = new ChromeDriver();
     // Navigate to the Facebook login page
     driver.get("https://www.facebook.com/");
     // Initialize FacebookLoginPage object
     facebookLoginPage = new FacebookLoginPage(driver);
 }

 @Test
 public void testLogin() {
     // Perform login using Page Object methods
     facebookLoginPage.enterEmail("7786054602");
     facebookLoginPage.enterPassword("samrat");
     facebookLoginPage.clickLoginButton();

     // Add assertions or verifications as needed
     // Example: Assert.assertTrue(driver.getTitle().contains("Facebook"));

     // You might want to add additional verifications based on the post-login state
 }

 @AfterMethod
 public void tearDown() {
     // Close the browser window
     driver.quit();
 }
}

